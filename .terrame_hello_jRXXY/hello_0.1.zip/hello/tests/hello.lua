-- Test file for hello.lua
-- Author: Daniel

return{
	Point = function(unitTest)
		-- add a test here 
	end,
	dobro = function(unitTest)
		-- add a test here 
	end,
}

