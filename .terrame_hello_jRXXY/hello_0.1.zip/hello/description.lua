version = "0.1"
license = "LGPL-3"
package = "hello"
title = "nos"
url = "http://www.terrame.org"
authors = "Daniel"
content = [[This package has funcionalities to create and manage a database to be used by any model in TerraME.
]]

date = "07 November 2022" -- automatically added by build